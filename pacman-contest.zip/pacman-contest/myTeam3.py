# myTeam.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import distanceCalculator
import random, time, util, sys
from game import Directions
import game
from util import nearestPoint


#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
               first='OffensiveReflexAgent', second='DefensiveReflexAgent'):
    """
    This function should return a list of two agents that will form the
    team, initialized using firstIndex and secondIndex as their agent
    index numbers.  isRed is True if the red team is being created, and
    will be False if the blue team is being created.

    As a potentially helpful development aid, this function can take
    additional string-valued keyword arguments ("first" and "second" are
    such arguments in the case of this function), which will come from
    the --redOpts and --blueOpts command-line arguments to capture.py.
    For the nightly contest, however, your team will be created without
    any extra arguments, so you should make sure that the default
    behavior is what you want for the nightly contest.
    """

    # The following line is an example only; feel free to change it.
    return [eval(first)(firstIndex), eval(second)(secondIndex)]


##########
# Agents #
##########

class DummyAgent(CaptureAgent):
    """
    A Dummy agent to serve as an example of the necessary agent structure.
    You should look at baselineTeam.py for more details about how to
    create an agent as this is the bare minimum.
    """

    def registerInitialState(self, gameState):

        """
        This method handles the initial setup of the
        agent to populate useful fields (such as what team
        we're on).

        A distanceCalculator instance caches the maze distances
        between each pair of positions, so your agents can use:
        self.distancer.getDistance(p1, p2)

        IMPORTANT: This method may run for at most 15 seconds.
        """

        '''
        Make sure you do not delete the following line. If you would like to
        use Manhattan distances instead of maze distances in order to save
        on initialization time, please take a look at
        CaptureAgent.registerInitialState in captureAgents.py.
        '''

        self.start = gameState.getAgentPosition(self.index)
        CaptureAgent.registerInitialState(self, gameState)
        self.foodCount = len(self.getFood(gameState).asList())
        self.defendingFoodCount = len(self.getFoodYouAreDefending(gameState).asList())
        self.score = self.getScore(gameState)
        self.time = time.time()
        self.count = 0
        self.direction = 1
        self.centerPos = ()
        self.safedots = []
        self.opponentsUP = False
        self.possibleEnemy = None
        self.lostfood = 0
        self.xCenter = 0
        self.defendLine = []

        if self.red:
            self.centerPos = (gameState.data.layout.width / 2 - 1, gameState.data.layout.height / 2 - 1)

            self.safeDots = [(int(gameState.data.layout.width / 2) - 2, int(y)) for y in
                             range(1, gameState.data.layout.height - 1)]
            self.xCenter = gameState.data.layout.width / 2 - 2

        else:
            self.centerPos = (gameState.data.layout.width / 2 + 1, gameState.data.layout.height / 2 + 1)

            self.safeDots = [(int(gameState.data.layout.width / 2) + 1, int(y)) for y in
                             range(1, gameState.data.layout.height - 1)]
            self.xCenter = gameState.data.layout.width / 2 + 1

        for dot in self.safeDots:
            x, y = dot
            if not gameState.hasWall(x, y):
                self.safedots.append(dot)


    # Astar algorithm
    def wastar(self, gameState, isGoalState, heuristic, danger):
        # currentPosition = gameState.getAgentPosition(self.index)
        prioQueue = util.PriorityQueue()
        curPos = gameState.getAgentPosition(self.index)
        prioQueue.push((curPos, [], gameState, gameState), 0 + 1 * heuristic(curPos, gameState,gameState))
        closed = []
        best_gn = {}
        Start = time.time()
        while not prioQueue.isEmpty():
            curPos, actions, curState, preState = prioQueue.pop()
            gn = len(actions)
            if curPos not in closed or best_gn[curPos] > gn:
                best_gn[curPos] = gn
                closed.append(curPos)
                if isGoalState(curPos, preState):
                    return actions
                if(time.time()-Start >0.9):
                    return actions

                legalActions = curState.getLegalActions(self.index)
                legalActions.remove('Stop')

                successors = [self.getSuccessor(curState, legalAction) for legalAction in legalActions]
                for (successor, action) in zip(successors, legalActions):
                    succPos = successor.getAgentPosition(self.index)
                    preState = curState
                    if danger:
                        if succPos != self.start:
                            prioQueue.push((succPos, actions + [action], successor, preState),
                                           gn + 1 + 1 * heuristic(succPos, successor, preState))
                    else:
                        prioQueue.push((succPos, actions + [action], successor, preState),
                                       gn + 1 + 1 * heuristic(succPos, successor, preState))

        return []

        # Astar algorithm
    def escapeWastar(self, gameState, isGoalState, heuristic):
        # currentPosition = gameState.getAgentPosition(self.index)
        prioQueue = util.PriorityQueue()
        curPos = gameState.getAgentPosition(self.index)
        prioQueue.push((curPos, [], gameState,gameState), 0 + 1 * heuristic(curPos, gameState,gameState))
        closed = []
        best_gn = {}
        Start = time.time()
        while not prioQueue.isEmpty():
            curPos, actions, curState,preState = prioQueue.pop()
            gn = len(actions)
            if curPos not in closed or best_gn[curPos] > gn:
                best_gn[curPos] = gn
                closed.append(curPos)
                if isGoalState(curPos, preState):
                    return actions
                if(time.time()-Start >0.6):
                    return []

                legalActions = curState.getLegalActions(self.index)
                legalActions.remove('Stop')

                successors = [self.getSuccessor(curState, legalAction) for legalAction in legalActions]
                for (successor, action) in zip(successors, legalActions):
                    succPos = successor.getAgentPosition(self.index)
                    preState = curState
                    if succPos != self.start and not self.isDeadEnd(successor, curState):
                        prioQueue.push((succPos, actions + [action], successor, preState),
                                       gn + 1 + 1 * heuristic(succPos, successor, preState))

        return []

        '''
        Your initialization code goes here, if you need any.
        '''

    def isOpenPoint(self,curPosition,gameState):
        x,y = curPosition
        walls = 0
        if gameState.hasWall(x + 1, y):
            walls += 1
        if gameState.hasWall(x - 1, y):
            walls += 1
        if gameState.hasWall(x, y + 1):
            walls += 1
        if gameState.hasWall(x, y - 1):
            walls += 1
        if walls <=2:
            return True
        return False

    def showTime(self,curState):
        legalActions = curState.getLegalActions(self.index)
        legalActions.remove('Stop')
        path = 'Stop'
        successors = [self.getSuccessor(curState, legalAction) for legalAction in legalActions]
        distance = -1
        for successor, action in zip(successors,legalActions):
            if successor.getAgentPosition(self.index) == self.start:
                pass
            if distance < self.nearestGhost(successor):
                distance = self.nearestGhost(successor)
                path = action
        if distance != -1:
            return action
        else:
            return 'Stop'

    def findFarestDirection(self, gameState, Legalactions):
        # print("FARFARFAR")
        # print(Legalactions)
        if self.nearestGhostIndex(gameState) != 999:
            enemy = gameState.getAgentState(self.nearestGhostIndex(gameState))
            dic = {}
            enemyPos = enemy.getPosition()
            Legalactions.remove('Stop')
            successors = [self.getSuccessor(gameState, legalAction) for legalAction in Legalactions]
            for (successor, action) in zip(successors, Legalactions):
                if not self.isDeadEnd(successor, gameState):
                    succPos = successor.getAgentPosition(self.index)
                    if succPos != self.start:
                        dic[self.getMazeDistance(enemyPos, succPos)] = action

            minDis = min(dic.keys())
            maxDis = max(dic.keys())
            # print(dic)
            if minDis <= 5:
                # print(dic[maxDis])
                return dic[maxDis]
            else:
                # print(dic[minDis])
                return dic[minDis]
        else:
            return "Stop"


    def isDeadEnd(self,gameState,iniState):
        depth = 20

        closed = [iniState.getAgentPosition(self.index)]
        from collections import deque
        Queue = []
        Queue.append(gameState)
        open = 0
        dead = 0
        while(len(Queue) != 0 and depth > 0 ):
            cur_state = Queue.pop()
            cur_pos = cur_state.getAgentPosition(self.index)
            if cur_pos not in closed:
                closed.append(cur_pos)
                depth -= 1
                x,y = cur_pos
                walls = 0
                if cur_state.hasWall(x + 1, y):
                    walls += 1
                if cur_state.hasWall(x - 1, y):
                    walls += 1
                if cur_state.hasWall(x, y + 1):
                    walls += 1
                if cur_state.hasWall(x, y - 1):
                    walls += 1
                if walls >= 3:
                    dead += 1
                elif walls <= 1:
                    open += 1
                legalActions = cur_state.getLegalActions(self.index)
                legalActions.remove('Stop')
                successors = [self.getSuccessor(cur_state, legalAction) for legalAction in legalActions]
                for (successor, action) in zip(successors, legalActions):
                    succPos = successor.getAgentPosition(self.index)
                    if succPos != self.start:
                        Queue.append(successor)
        if dead - open > 0:
            return True
        else:
            return False

    def defastar(self, gameState, isGoalState, heuristic):
        # currentPosition = gameState.getAgentPosition(self.index)
        prioQueue = util.PriorityQueue()
        curPos = gameState.getAgentPosition(self.index)
        prioQueue.push((curPos, [], gameState,gameState), 0 + 1 * heuristic(curPos, gameState,gameState))
        closed = []
        best_gn = {}
        Start = time.time()
        while not prioQueue.isEmpty():
            curPos, actions, curState, preState = prioQueue.pop()
            gn = len(actions)
            if curPos not in closed or best_gn[curPos] > gn:
                best_gn[curPos] = gn
                closed.append(curPos)
                if isGoalState(curPos, gameState):
                    return actions
                if (time.time() - Start > 0.9):
                    return actions

                legalActions = curState.getLegalActions(self.index)
                legalActions.remove('Stop')

                successors = [self.getSuccessor(curState, legalAction) for legalAction in legalActions]
                for (successor, action) in zip(successors, legalActions):
                    succPos = successor.getAgentPosition(self.index)
                    preState = curState
                    prioQueue.push((succPos, actions + [action], successor,preState),
                                   gn + 1 + 1 * heuristic(succPos, successor, preState))

        return []

        '''
        Your initialization code goes here, if you need any.
        '''
    def findFoodZone(self,gameState):
        foods = []

        for food in self.getFood(gameState).asList():
            y = int(gameState.data.layout.height / 2)
            if self.direction == 1:
                if food[1] < y:
                    foods.append(food)
            else:
                if food[1] >= y:
                    foods.append(food)
        return foods
    # If the goal is Capsule
    def isCapsule(self, curPosition, gameState):
        if curPosition in self.getCapsules(gameState):
            return True
        else:
            return False

    def isDefendingPoint(self, curPosition, gameState):
        if curPosition in self.defendLine:
            return True
        else:
            return False

    def isInvader(self, curPosition, gameState):
        enemies = [gameState.getAgentState(i) for i in self.getOpponents(gameState)]
        invador = [a for a in enemies if a.isPacman and a.getPosition() != None]
        invadorPos = []
        for a in invador:
            invadorPos.append(a.getPosition())
        if curPosition in invadorPos:
            return True
        else:
            return False

    def nearestDefendingPoint(self, curPosition, gameState,preState):
        myPos = gameState.getAgentPosition(self.index)
        defendingPoint = self.defendLine
        distance = 9999

        for point in defendingPoint:
            if distance > self.getMazeDistance(myPos, point):
                distance = self.getMazeDistance(myPos, point)
        return distance

    def nearestInvador(self, curPosition, gameState, preState):
        myPos = gameState.getAgentPosition(self.index)
        enemies = [gameState.getAgentState(i) for i in self.getOpponents(gameState)]
        invador = [a for a in enemies if a.isPacman and a.getPosition() != None]
        invadorPos = []
        for a in invador:
            invadorPos.append(a.getPosition())

        distance = 9999
        for point in invadorPos:
            if distance > self.getMazeDistance(myPos, point):
                distance = self.getMazeDistance(myPos, point)
        return distance

    # If the goal is to get food
    def isFoods(self, curPosition, gameState):
        foods = self.findFoodZone(gameState)
        # if len(foods) == 0:
        if curPosition in foods:
            return True
        else:
            return False

    # If the goal is to get back home
    def isHome(self, curPosition, gameState):
        if curPosition in self.safeDots:
            return True
        else:
            return False

    # Get nearest capusle
    def nearestCapsuleIndex(self,gameState,preState):
        capsules = self.getCapsules(preState)
        if (len(capsules) == 0):
            return None
        else:
            for cap in capsules:
                if self.getMazeDistance(cap, gameState.getAgentPosition(self.index)):
                    return cap
    def nearestCapsule(self, gameState,preState):
        myPos = gameState.getAgentPosition(self.index)
        capsules = self.getCapsules(preState)
        if (len(capsules) == 0):
            return 9999
        distance = min([self.getMazeDistance(myPos, cap) for cap in capsules])
        # distance = 9999
        # if capsules != None:
        #     for capsule in capsules:
        #         if distance > self.getMazeDistance(myPos, capsule):
        #             distance = self.getMazeDistance(myPos, capsule)
        return distance

    # Get nearest ghost position
    def nearestGhost(self, gameState):
        myPos = gameState.getAgentPosition(self.index)
        enemiesIndex = self.getOpponents(gameState)
        enemies = [gameState.getAgentPosition(i) for i in self.getOpponents(gameState)]
        dist = 9999
        if enemies != None:
            for enemyIndex in enemiesIndex:
                if gameState.getAgentPosition(enemyIndex) and not gameState.getAgentState(enemyIndex).isPacman:
                    if self.getMazeDistance(gameState.getAgentPosition(enemyIndex), myPos) < dist:
                        dist = self.getMazeDistance(gameState.getAgentPosition(enemyIndex), myPos)
        return dist

    #Get nearest ghost index 999 or index
    def nearestGhostIndex(self, gameState):
        myPos = gameState.getAgentPosition(self.index)
        enemies = self.getOpponents(gameState)
        distance = 9999
        i = 999
        if enemies != None:
            for enemy in enemies:
                if gameState.getAgentPosition(enemy) and not gameState.getAgentState(enemy).isPacman:
                    if distance > self.getMazeDistance(myPos, gameState.getAgentPosition(enemy)):
                        distance = self.getMazeDistance(myPos, gameState.getAgentPosition(enemy))
                        i = enemy
        return i

    # Get nearest food position
    def nearestFood(self, gameState,preState):
        myPos = gameState.getAgentPosition(self.index)
        foods = self.findFoodZone(preState)
        if(len(foods) == 0):
            return 9999
        distance = min([self.getMazeDistance(myPos, food) for food in foods])
        # distance = 9999
        # nearestFood = (99,99)
        # if foods != None:
        #     for food in foods:
        #         if distance > self.getMazeDistance(myPos, food):
        #             distance = self.getMazeDistance(myPos, food)
        return distance
    def nearestFoodPos(self, gameState,preState):
        myPos = gameState.getAgentPosition(self.index)
        foods = self.findFoodZone(preState)

        distance = 9999
        nearestFood = (99,99)
        if foods != None:
            for food in foods:
                if distance > self.getMazeDistance(myPos, food):
                    distance = self.getMazeDistance(myPos, food)
                    nearestFood = food
        return nearestFood

    # Get farthest food position
    def farthestFood(self, gameState):
        myPos = gameState.getAgentPosition(self.index)
        foods = self.findFoodZone(gameState)
        distance = -1
        if foods != None:
            for food in foods:
                if distance < self.getMazeDistance(myPos, food):
                    distance = self.getMazeDistance(myPos, food)
        return distance

    # Get nearest home position
    def nearestHome(self, gameState):
        distance = 9999
        myPos = gameState.getAgentPosition(self.index)
        distance = self.getMazeDistance(myPos, self.start)
        # for safeSpot in self.safeDots:
        #     x, y = safeSpot
        #     if not gameState.hasWall(x, y):
        #         if distance > self.getMazeDistance(myPos, safeSpot):
        #             distance = self.getMazeDistance(myPos, safeSpot)
        return distance



    def TopHome(self, curPosition, gameState):
        return curPosition == self.safedots[-1]

    def getTopHomeDistance(self, curPos, gameState):
        return self.getMazeDistance(gameState.getAgentPosition(self.index), self.safedots[-1])

    def BottomHome(self, curPosition, gameState):
        return curPosition == self.safedots[0]

    def getBottomHomeDistance(self, curPos, gameState):
        return self.getMazeDistance(gameState.getAgentPosition(self.index), self.safedots[0])

    # Get farthest home position
    def farthestHome(self, gameState):
        distance = -1
        myPos = gameState.getAgentPosition(self.index)
        for safeSpot in self.safeDots:
            x, y = safeSpot
            if not gameState.hasWall(x, y):
                if distance < self.getMazeDistance(myPos, safeSpot):
                    distance = self.getMazeDistance(myPos, safeSpot)
        return distance

    # Return True if observed ghost(for both characters)
    def IvGtYuInMySt(self, gameState):
        myPos = gameState.getAgentPosition(self.index)
        enemiesIndex = self.getOpponents(gameState)
        enemies = [gameState.getAgentPosition(i) for i in self.getOpponents(gameState)]
        if len(enemies) == 0 or enemies == None:
            return False
        if gameState.getAgentState(self.index).isPacman or gameState.getAgentPosition(self.index)[0] >= self.xCenter:
            if gameState.getAgentPosition(enemiesIndex[0]) or gameState.getAgentPosition(enemiesIndex[1]):
                    return True
        return False

    # Do not eat food in the deadend
    def MuDaMuDaMuDa(self, curPosition, gameState):
        walls = 0
        x, y = curPosition
        if self.isFoods(curPosition, gameState):
            if gameState.hasWall(x + 1, y):
                walls += 1
            if gameState.hasWall(x - 1, y):
                walls += 1
            if gameState.hasWall(x, y + 1):
                walls += 1
            if gameState.hasWall(x, y - 1):
                walls += 1
            if walls >= 3:
                return False
            else:
                return True

    # Go to Capsule
    def RushCapHeur(self, curPos, gameState, preState):
        # if self.nearestGhost(gameState) <=3:
        #     return self.nearestCapsule(preState) - self.nearestGhost(gameState) * 99
        return self.nearestCapsule(gameState,preState) - self.nearestGhost(gameState) * 3

    # Go! Go! Go!
    def RushBHeur(self, curPos, gameState, preState):

        # if not self.IvGtYuInMySt(gameState):
        #     return self.nearestFood(preState)
        # else:
        #     return self.nearestFood(preState) - self.nearestGhost(gameState) * 99
        return self.nearestFood(gameState,preState) - self.nearestGhost(gameState) * 3

    def RushFoodHeur(self, curPos, gameState, preState):
        return self.nearestFood(gameState,preState)

    # Run Pacman Run!
    def RushHomeHeur(self, curPos, gameState,preState):
        return self.nearestHome(gameState) - self.nearestGhost(gameState) * 3
    def RushScoreHeur(self,curPos,gameState,preState):
        return self.nearestHome(gameState)

    def EscapeHeur(self, curPos, gameState, preState):
        return self.nearestFood(preState) - self.nearestGhost(gameState) + self.farthestHome(gameState)

    def getSuccessor(self, gameState, action):
        """
        Finds the next successor which is a grid position (location tuple).
        """
        successor = gameState.generateSuccessor(self.index, action)
        pos = successor.getAgentState(self.index).getPosition()
        if pos != nearestPoint(pos):
            # Only half a grid position was covered
            return successor.generateSuccessor(self.index, action)
        else:
            return successor
    # EnemyScared
    def KoNoDioDa(self, gameState):
        if self.nearestGhostIndex(gameState) < 999:
            enemy = gameState.getAgentState(self.nearestGhostIndex(gameState))
            if enemy.scaredTimer > 1:
                return True
        return False

    def chooseAction(self, gameState):
        actions = gameState.getLegalActions(self.index)
        """
        Picks among actions randomly.
        """
        return random.choice(actions)
        '''
        You should change this in your own agent.
        '''


    def evaluate(self, gameState, action):
        """
        Computes a linear combination of features and feature weights
        """
        features = self.getFeatures(gameState, action)
        weights = self.getWeights(gameState, action)
        return features * weights


    def getFeatures(self, gameState, action):
        """
        Returns a counter of features for the state
        """
        features = util.Counter()
        successor = self.getSuccessor(gameState, action)
        features['successorScore'] = self.getScore(successor)
        return features

    def getWeights(self, gameState, action):
        """
        Normally, weights do not depend on the gamestate.  They can be either
        a counter or a dictionary.
        """
        return {'successorScore': 1.0}
        """
        This method handles the initial setup of the
        agent to populate useful fields (such as what team
        we're on).

        A distanceCalculator instance caches the maze distances
        between each pair of positions, so your agents can use:
        self.distancer.getDistance(p1, p2)

        IMPORTANT: This method may run for at most 15 seconds.
        """

        '''
        Make sure you do not delete the following line. If you would like to
        use Manhattan distances instead of maze distances in order to save
        on initialization time, please take a look at
        CaptureAgent.registerInitialState in captureAgents.py.
        '''
        CaptureAgent.registerInitialState(self, gameState)

        '''
        Your initialization code goes here, if you need any.
        '''


class OffensiveReflexAgent(DummyAgent):
    def registerInitialState(self, gameState):

        """
        This method handles the initial setup of the
        agent to populate useful fields (such as what team
        we're on).

        A distanceCalculator instance caches the maze distances
        between each pair of positions, so your agents can use:
        self.distancer.getDistance(p1, p2)

        IMPORTANT: This method may run for at most 15 seconds.
        """

        '''
        Make sure you do not delete the following line. If you would like to
        use Manhattan distances instead of maze distances in order to save
        on initialization time, please take a look at
        CaptureAgent.registerInitialState in captureAgents.py.
        '''

        self.start = gameState.getAgentPosition(self.index)
        CaptureAgent.registerInitialState(self, gameState)
        self.foodCount = len(self.getFood(gameState).asList())
        self.defendingFoodCount = len(self.getFoodYouAreDefending(gameState).asList())
        self.score = self.getScore(gameState)
        self.time = time.time()
        self.count = 0
        self.direction = 1
        self.centerPos = ()
        self.safedots = []
        self.opponentsUP = False
        self.possibleEnemy = None
        self.lostfood = 0
        self.xCenter = 0

        if self.red:
            self.centerPos = (gameState.data.layout.width / 2 - 1, gameState.data.layout.height / 2 - 1)

            self.safeDots = [(int(gameState.data.layout.width / 2) - 2, int(y)) for y in
                             range(1, gameState.data.layout.height - 1)]
            self.xCenter = gameState.data.layout.width / 2 - 2

        else:
            self.centerPos = (gameState.data.layout.width / 2 - 1, gameState.data.layout.height / 2 + 1)

            self.safeDots = [(int(gameState.data.layout.width / 2) + 1, int(y)) for y in
                             range(1, gameState.data.layout.height - 1)]
            self.xCenter = (gameState.data.layout.width / 2 + 1) * (-1)

        for dot in self.safeDots:
            x, y = dot
            if not gameState.hasWall(x, y):
                self.safedots.append(dot)

        if self.red:
            Def1 = [(int(gameState.data.layout.width / 2) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def2 = [(int(gameState.data.layout.width / 2) - 2, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def3 = [(int(gameState.data.layout.width / 2) - 3, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def4 = [(int(gameState.data.layout.width / 2) - 4, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
        else:
            Def1 = [(int(gameState.data.layout.width / 2), int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def2 = [(int(gameState.data.layout.width / 2+1) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def3 = [(int(gameState.data.layout.width / 2+2) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def4 = [(int(gameState.data.layout.width / 2+3) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
        DefList1 = []
        DefList2 = []
        DefList3 = []
        DefList4 = []

        for dot in Def1:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList1.append(dot)
        for dot in Def2:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList2.append(dot)
        for dot in Def3:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList3.append(dot)
        for dot in Def4:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList4.append(dot)
        result = []
        minlen = min(len(DefList1), len(DefList2), len(DefList3), len(DefList4))

        allFourLine = [DefList1, DefList2, DefList3, DefList4]
        # print(allFourLine)
        for line in allFourLine:
            if len(line) == minlen:
                result.append(line)
        shortestLine = random.choice(result)

        defend = (int(gameState.data.layout.width // 2), int(gameState.data.layout.height // 3))
        minDis = 99999
        choosepoint = None
        for point in shortestLine:
            dis = util.manhattanDistance(point, defend)
            if dis < minDis:
                choosepoint = point
                minDis = dis
        self.defendLine = [choosepoint]
    # def LoadingDot(self,gameState):
    #  dotCarry = self.inifood - len(self.getFood(gameState).asList())
    #  return dotCarry

    def findLostFood(self, gameState):
        currentFoodCount = len(self.getFoodYouAreDefending(gameState).asList())
        if self.defendingFoodCount - currentFoodCount > 0:
            lastState = self.getPreviousObservation()
            if lastState:
                nearestDistance = []
                for item in self.getFoodYouAreDefending(lastState).asList():
                    if item not in self.getFoodYouAreDefending(gameState).asList():
                        if item:
                            return item
                        # nearestDistance.append(self.getMazeDistance(gameState.getAgentPosition(self.index), item))

        return None

    def chooseAction(self, gameState):
        agent = gameState.getAgentState(self.index)
        myState = gameState.getAgentState(self.index)
        myPos = myState.getPosition()
        number = gameState.getAgentState(self.index).numCarrying

        LegalActions = gameState.getLegalActions(self.index)
        # print(LegalActions)
        paths = []

        danger = self.IvGtYuInMySt(gameState)
        if self.KoNoDioDa(gameState):
            danger = False
        # print(danger)

        if self.getMazeDistance(gameState.getAgentPosition(self.index), self.safedots[0]) == 1:
            self.count = 1

        if self.getPreviousObservation() is not None:
            preState = self.getPreviousObservation()
            if self.getMazeDistance(preState.getAgentPosition(self.index), gameState.getAgentPosition(self.index)) > 1:
                self.count = 0
        foods = self.findFoodZone(gameState)

        if len(foods) == 0 and number == 0:
            self.direction = 0
            foods = self.findFoodZone(gameState)

        if (len(self.getFood(gameState).asList()) <= 2 or len(foods) == 0) and ((self.red and myPos[0] >= self.centerPos[0]) or (
                    (not self.red) and myPos[0] <= self.centerPos[0])):
            if danger:
                paths = self.wastar(gameState, self.isHome, self.RushHomeHeur,danger)
            else:
                paths = self.wastar(gameState,self.isHome, self.RushScoreHeur,danger)
            # print('溜了溜了溜了')
            if len(paths) != 0: return paths[0]
            legalActions = gameState.getLegalActions(self.index)
            # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
            curPath = self.findFarestDirection(gameState, legalActions)
            # print(curPath)
            return curPath

        if (agent.scaredTimer or gameState.data.timeleft > 200) and len(self.getFood(gameState).asList()) > 2:
            # if self.count == 0:
            #     paths = self.wastar(gameState, self.BottomHome, self.getBottomHomeDistance)
            #     if paths == []:
            #         return random.choice(LegalActions)
            #     return paths[0]
            #
            # # print(danger)
            # elif len(self.getFood(gameState).asList()) == 0 and ((self.red and myPos[0] > self.centerPos[0]) or (
            #         (not self.red) and myPos[0] < self.centerPos[0])):
            #     paths = self.wastar(gameState, self.isHome, self.RushHomeHeur)
            #     if len(paths) > 0:
            #         if paths[0] in LegalActions:
            #             self.inifood = len(self.getFood(gameState).asList())
            #             return paths[0]
            #     len(self.getFood(gameState).asList())
            #     return "Stop"
            # else:
            # print(str(self.index) +' 离鬼的距离 ' + str(self.nearestGhost(gameState)))
            # print(str(self.index) + '的终点' + str(gameState.getAgentPosition(self.index)[0] >= self.xCenter))
            Start = time.time()
            if danger:
                if self.nearestGhost(gameState) <= 3 and (gameState.getAgentState(self.index).isPacman or
                                                          gameState.getAgentPosition(self.index)[0] >= self.xCenter):
                    if len(self.getCapsules(gameState)) != 0:
                        # print(str(self.index) + "FindCap")
                        paths = self.wastar(gameState, self.isCapsule, self.RushCapHeur,danger)

                        # print('红色的的老哥')
                        # preState = self.getPreviousObservation()
                        # print(self.nearestCapsule(gameState, preState))
                        # print(myPos)
                        # print(self.getCapsules(gameState))
                        # print(paths)
                    else:
                        if number >= 4:
                            # print(str(self.index) + "Go Home when chased")
                            paths = self.wastar(gameState, self.isHome, self.RushHomeHeur,danger)
                        else:
                            Start =time.time()
                            # print(str(self.index) + "Eat food when chased")
                            paths = self.escapeWastar(gameState, self.isFoods, self.RushBHeur)
                            # print('耗时' + str(time.time() - Start))
                            if len(paths) == 0:
                                # print('showTime')
                                # print('最近的food')
                                preState = self.getPreviousObservation()
                                # print(self.nearestFood(gameState,preState))

                else:
                    # print(str(self.index) + "eat food In Danger")
                    paths = self.wastar(gameState, self.isFoods, self.RushFoodHeur,danger)
            else:
                # print(str(self.index) + "eat food no danger")
                paths = self.wastar(gameState, self.isFoods, self.RushFoodHeur,danger)
                # print('红色的老哥')
                # print(gameState.getAgentPosition(self.index))
                # print(self.findFoodZone(gameState))
                # print(self.nearestFoodPos(gameState))
                # print(paths[0])
                # print('距离' + str(self.nearestFood(gameState)))
            if len(paths) > 0:
                if paths[0] in LegalActions:
                    return paths[0]
            legalActions = gameState.getLegalActions(self.index)
            # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
            curPath = self.findFarestDirection(gameState, legalActions)
            # print(time.time() - Start)
            # print(curPath)
            return curPath
            # print('showTime')
            # print(curPath)

        elif gameState.data.timeleft <= 200 and (self.red and myPos[0] > self.centerPos[0]) or (
                (not self.red) and myPos[0] < self.centerPos[0]):
            paths = self.wastar(gameState, self.isHome, self.RushHomeHeur,danger)
            if len(paths) > 0:
                if paths[0] in LegalActions:
                    self.inifood = len(self.getFood(gameState).asList())
                    return paths[0]

            legalActions = gameState.getLegalActions(self.index)
            # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
            curPath = self.findFarestDirection(gameState, legalActions)
            # print(curPath)
            return curPath
        else:
            enemies = [gameState.getAgentState(i) for i in self.getOpponents(gameState)]
            invaders = [a for a in enemies if a.isPacman and a.getPosition() != None]
            if len(invaders) > 0:
                paths = self.defastar(gameState, self.isInvader, self.nearestInvador)
            else:
                paths = self.defastar(gameState, self.isDefendingPoint, self.nearestDefendingPoint)
            if len(paths) > 0:
                if paths[0] in LegalActions:
                    return paths[0]
            return "Stop"


class DefensiveReflexAgent(DummyAgent):
    """
    A reflex agent that keeps its side Pacman-free. Again,
    this is to give you an idea of what a defensive agent
    could be like.  It is not the best or only way to make
    such an agent.
    """
    def registerInitialState(self, gameState):

        """
        This method handles the initial setup of the
        agent to populate useful fields (such as what team
        we're on).

        A distanceCalculator instance caches the maze distances
        between each pair of positions, so your agents can use:
        self.distancer.getDistance(p1, p2)

        IMPORTANT: This method may run for at most 15 seconds.
        """

        '''
        Make sure you do not delete the following line. If you would like to
        use Manhattan distances instead of maze distances in order to save
        on initialization time, please take a look at
        CaptureAgent.registerInitialState in captureAgents.py.
        '''

        self.start = gameState.getAgentPosition(self.index)
        CaptureAgent.registerInitialState(self, gameState)
        self.foodCount = len(self.getFood(gameState).asList())
        self.defendingFoodCount = len(self.getFoodYouAreDefending(gameState).asList())
        self.score = self.getScore(gameState)
        self.time = time.time()
        self.count = 0
        self.direction = 0
        self.centerPos = ()
        self.safedots = []
        self.opponentsUP = False
        self.possibleEnemy = None
        self.lostfood = 0
        self.xCenter = 0

        if self.red:
            self.centerPos = (gameState.data.layout.width / 2 - 1, gameState.data.layout.height / 2 - 1)

            self.safeDots = [(int(gameState.data.layout.width / 2) - 2, int(y)) for y in
                             range(1, gameState.data.layout.height - 1)]
            self.xCenter = gameState.data.layout.width / 2 - 2

        else:
            self.centerPos = (gameState.data.layout.width / 2 + 1, gameState.data.layout.height / 2 + 1)

            self.safeDots = [(int(gameState.data.layout.width / 2) + 1, int(y)) for y in
                             range(1, gameState.data.layout.height - 1)]
            self.xCenter = gameState.data.layout.width / 2 + 1

        for dot in self.safeDots:
            x, y = dot
            if not gameState.hasWall(x, y):
                self.safedots.append(dot)

        if self.red:
            Def1 = [(int(gameState.data.layout.width / 2) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def2 = [(int(gameState.data.layout.width / 2) - 2, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def3 = [(int(gameState.data.layout.width / 2) - 3, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def4 = [(int(gameState.data.layout.width / 2) - 4, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
        else:
            Def1 = [(int(gameState.data.layout.width / 2), int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def2 = [(int(gameState.data.layout.width / 2+1) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def3 = [(int(gameState.data.layout.width / 2+2) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
            Def4 = [(int(gameState.data.layout.width / 2+3) - 1, int(y)) for y in
                    range(1, gameState.data.layout.height - 1)]
        DefList1 = []
        DefList2 = []
        DefList3 = []
        DefList4 = []

        for dot in Def1:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList1.append(dot)
        for dot in Def2:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList2.append(dot)
        for dot in Def3:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList3.append(dot)
        for dot in Def4:
            x, y = dot
            if not gameState.hasWall(x, y):
                DefList4.append(dot)
        result = []
        minlen = min(len(DefList1), len(DefList2), len(DefList3), len(DefList4))

        allFourLine = [DefList1, DefList2, DefList3, DefList4]
        # print(allFourLine)
        for line in allFourLine:
            if len(line) == minlen:
                result.append(line)
        shortestLine = random.choice(result)
        defend = (int(gameState.data.layout.width // 2), int(gameState.data.layout.height * 2 // 3))
        minDis = 99999
        choosepoint = None
        for point in shortestLine:
            dis = util.manhattanDistance(point, defend)
            if dis < minDis:
                choosepoint = point
                minDis = dis
        self.defendLine = [choosepoint]



    def findLostFood(self, gameState):
        currentFoodCount = len(self.getFoodYouAreDefending(gameState).asList())
        if self.defendingFoodCount - currentFoodCount > 0:
            lastState = self.getPreviousObservation()
            if lastState:
                nearestDistance = []
                for item in self.getFoodYouAreDefending(lastState).asList():
                    if item not in self.getFoodYouAreDefending(gameState).asList():
                        if item:
                            return item
                        # nearestDistance.append(self.getMazeDistance(gameState.getAgentPosition(self.index), item))

        return None

    def chooseAction(self, gameState):
        """
        Picks among the actions with the highest Q(s,a).
        """
        agent = gameState.getAgentState(self.index)
        myState = gameState.getAgentState(self.index)
        myPos = myState.getPosition()
        number = gameState.getAgentState(self.index).numCarrying

        LegalActions = gameState.getLegalActions(self.index)
        # print(LegalActions)
        paths = []

        danger = self.IvGtYuInMySt(gameState)
        if self.KoNoDioDa(gameState):
            danger = False

        if self.getMazeDistance(gameState.getAgentPosition(self.index), self.safedots[0]) == 1:
            self.count = 1

        if self.getPreviousObservation() is not None:
            preState = self.getPreviousObservation()
            if self.getMazeDistance(preState.getAgentPosition(self.index), gameState.getAgentPosition(self.index)) > 1:
                self.count = 0
        foods = self.findFoodZone(gameState)
        if len(foods) == 0 and number == 0:
            self.direction = 1
            foods = self.findFoodZone(gameState)
        if (len(self.getFood(gameState).asList()) <= 2 or len(foods) == 0) and ((self.red and myPos[0] >= self.centerPos[0]) or (
                    (not self.red) and myPos[0] <= self.centerPos[0])):
            if danger:
                paths = self.wastar(gameState, self.isHome, self.RushHomeHeur, danger)
            else:
                paths = self.wastar(gameState, self.isHome, self.RushScoreHeur, danger)
            if len(paths) != 0: return paths[0]
            legalActions = gameState.getLegalActions(self.index)
            # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
            curPath = self.findFarestDirection(gameState, legalActions)
            # print(curPath)
            return curPath
        if (agent.scaredTimer or gameState.data.timeleft > 200 ) and len(self.getFood(gameState).asList()) > 2:
            Start = time.time()
            if danger:
                if self.nearestGhost(gameState) <=3 and (gameState.getAgentState(self.index).isPacman or
                                                         gameState.getAgentPosition(self.index)[0] >= self.xCenter):
                    if len(self.getCapsules(gameState)) != 0:
                        # print(str(self.index) + "FindCap")
                        paths = self.wastar(gameState, self.isCapsule, self.RushCapHeur,danger)
                        # print('橙色老哥')

                        # print(paths)
                    else:
                        if number >= 4:
                            # print(str(self.index) + "Go Home when chased")
                            paths = self.wastar(gameState, self.isHome, self.RushHomeHeur,danger)
                        else:

                            # print(str(self.index) + "Eat food when chased")
                            paths = self.escapeWastar(gameState, self.isFoods, self.RushBHeur)

                            if len(paths) == 0:
                                # print('showTime')
                                # print('最近的food')
                                preState = self.getPreviousObservation()
                                # print(self.nearestFood(gameState, preState))

                else:
                    # print(str(self.index) + "eat food In Danger")
                    paths = self.wastar(gameState, self.isFoods, self.RushFoodHeur,danger)
            else:
                # print(str(self.index) + "eat food no danger")
                paths = self.wastar(gameState, self.isFoods, self.RushFoodHeur,danger)
            if len(paths) > 0:
                if paths[0] in LegalActions:
                    return paths[0]
            legalActions = gameState.getLegalActions(self.index)
            # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
            curPath = self.findFarestDirection(gameState, legalActions)
            # print(curPath)
            # print('耗时' + str(time.time() - Start))
            return curPath
        elif gameState.data.timeleft <= 200 and (self.red and myPos[0] > self.centerPos[0]) or (
                (not self.red) and myPos[0] < self.centerPos[0]):
            paths = self.wastar(gameState, self.isHome, self.RushHomeHeur,danger)
            if len(paths) > 0:
                if paths[0] in LegalActions:
                    self.inifood = len(self.getFood(gameState).asList())
                    return paths[0]
            len(self.getFood(gameState).asList())
            legalActions = gameState.getLegalActions(self.index)
            # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
            curPath = self.findFarestDirection(gameState, legalActions)
            # print(curPath)
            return curPath
        else:
            enemies = [gameState.getAgentState(i) for i in self.getOpponents(gameState)]
            invaders = [a for a in enemies if a.isPacman and a.getPosition() != None]
            if len(invaders) > 0:
                paths = self.defastar(gameState, self.isInvader, self.nearestInvador)
            else:
                paths = self.defastar(gameState, self.isDefendingPoint, self.nearestDefendingPoint)
            if len(paths) > 0:
                if paths[0] in LegalActions:
                    return paths[0]

            return "Stop"



